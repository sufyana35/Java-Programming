/**
 * Driver for the LabClass.
 * 
 * @author Ian Bradley 
 * @version 14-03-2008
 */
public class AccountDriver
{
	public static void main(String[] args)
	{
		AccountTUI accountTUI = new AccountTUI();
		accountTUI.menu();
	}
}
