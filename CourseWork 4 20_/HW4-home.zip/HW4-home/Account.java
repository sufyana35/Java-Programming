/**
 * Write a description of class Account here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Account
{
    private String station;
    private String date;
    private String time;
    private int type;
    private int quantity;
    private int cost;
    private Address address;

    /**
     * Constructor for objects of class Account.
     * The number of pointsHeld should be set to zero.
     * 
     * @param firstName The Account Holder's first name 
     * @param lastName The Account Holder's last name
     * @param accNumber The Account Holder's account number
     * @param street the account holder's street
     * @param town the account holder's town
     * @param postcode the account holder's postcode
     */
    public Account(String nStation, String nDate, String nTime,
                   int nType, int nQuantity, int nCost)
    {
        station = nStation;
        date = nDate;
        time = nTime;
        type = nType;
        quantity = nQuantity;
        cost = nCost;

    }
    
    /**
     * Constructor for objects of class Account.
     * The number of pointsHeld should should be set to
     * the supplied value.
     * 
     * @param fName The Account Holder's first name 
     * @param lName The Account Holder's last name
     * @param acctNumber The account number
     * @param thePoints the pointsHeld awarded when account is initialised
     * @param street the account holder's street
     * @param town the account holder's town
     * @param postcode the account holder's postcode
     */
    public Account(String nStation, String nDate, String nTime, int nType,
                   int nQuantity, int nCost, String postcode)
    {
        station = nStation;
        date = nDate;
        time = nTime;
        type = nType;
        quantity = nQuantity;
        cost = nCost;
    }
    
    // accessors
    
    /**
     * Get the Account Holder's first name
     * 
     * @return the Account Holder's first name
     */
    public String getFirstName()
    {
        return station;
    }
    
    /**
     * Get the Account Holder's last name
     * 
     * @return the Account Holder's last name
     */
    public String getLastName()
    {
        return date;
    }
    
    /**
     * Get the Account Holder's account Number
     * 
     * @return the Account Holder's account number
     */
    public String getAccountNumber()
    {
        return time;
    }
    
     /**
     * Get the number of points held
     * 
     * @return the number of points held
     */
    public int getNoOfPoints()
    {
        return type;
    }
    

    public void printAccountDetails()
    {
        System.out.println("Station" + station + "\nDate " + date 
                           + "\nTime: " + time
                           + "\nType: " + type
                           + "\nAmount of fuel: " + quantity + "\nCost £" + cost);
    }     
    
    /**
     * Return the account holder's address
     * 
     * @return the account holder's address
     */
    public String getAddress()
    {
        return address.getFullAddress();
    }
    
    // mutators     
    
    /**
     * Change the first name
     * 
     * @param fName the new first name
     * 
     */
    public void setFirstName(String nStation)
    {
        station = nStation;
    }
    
    /**
     * Change the last name
     * 
     * @param lName the new last name
     * 
     */
    public void setLastName(String nDate)
    {
        date = nDate;
    }
    
    /**
     * Increase the number of points held by a given number
     * and output a esage to the console window giving 
     * the revised number of points held.
     * 
     * @param number of points to add to total
     */
    public void addPoints(int nQuantity)
    {
        quantity = quantity + quantity;
        System.out.println("Points now held: " + quantity);        
    }
    
    
    /**
     *  Change the account holder's address
     *  
     *  @param street the street
     *  @param town the town
     *  @postcode the postcode
     */
    public void setAddress(String street, String town, String postcode)
    {
        address.setFullAddress(street, town, postcode);
    }
    
    /** 
     * Print the account holder's address
     */
     public void printAddress()
     {
         address.printAddress();
     }    
} // end class
